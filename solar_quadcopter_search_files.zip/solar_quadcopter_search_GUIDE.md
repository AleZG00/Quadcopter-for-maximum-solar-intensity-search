## Tools
- 3D printer (PETG and PLA capable)
- Soldering iron with fine tip
- Solder (lead-free recommended)
- Wire strippers
- Heat shrink gun or lighter
- M3 hex key
- M2 screwdriver
- Hobby knife
- Small pliers
- Multimeter
- Zip tie cutters

## Assumptions
- Basic soldering experience is required.
- Familiarity with basic electronics concepts (e.g., polarity, voltage).
- Access to a computer with USB for flight controller configuration.
- Basic understanding of 3D printer operation and maintenance.
- Knowledge of quadcopter flight controller firmware flashing and setup (e.g., Betaflight, ArduPilot).

## 1. Fabrication
### 1.1 3D print all PETG mechanical components
*(not yet generated)*

### 1.2 3D print all PLA mechanical components
*(not yet generated)*

### 1.3 Deburr and clean all 3D printed parts and carbon fiber motor mounts
*(not yet generated)*

## 2. Wiring
### 2.1 Solder all four brushless motors to the ESC motor outputs
*(not yet generated)*

### 2.2 Solder main LiPo battery XT60 connector to ESC battery input
*(not yet generated)*

### 2.3 Connect ESC 5V output and signal wires to Flight Controller
*(not yet generated)*

### 2.4 Solder all four solar panels in parallel and connect to DC-DC Boost Converter input
*(not yet generated)*

### 2.5 Connect DC-DC Boost Converter output to LiPo battery charging input
*(not yet generated)*

### 2.6 Connect RC Receiver SBUS data and 5V/GND to Flight Controller UART1
*(not yet generated)*

### 2.7 Connect all four Light Sensors (power and analog out) to Flight Controller GPIO pins
*(not yet generated)*

### 2.8 Solder Current Sensor output from ESC to Flight Controller VBAT input
*(not yet generated)*

## 3. Bring-up
### 3.1 Verify continuity of all soldered electrical connections with a multimeter
*(not yet generated)*

### 3.2 Flash appropriate firmware (e.g., Betaflight) to the Flight Controller
*(not yet generated)*

### 3.3 Configure ESCs (motor direction, DShot protocol) and calibrate if necessary
*(not yet generated)*

### 3.4 Calibrate IMU and Compass on the Flight Controller
*(not yet generated)*

### 3.5 Verify RC Receiver signal detection and channel mapping in Flight Controller software
*(not yet generated)*

### 3.6 Test Light Sensors: verify analog readings change with light intensity in Flight Controller software
*(not yet generated)*

### 3.7 Test Solar Panel charging circuit: verify DC-DC converter output voltage and charging into LiPo
*(not yet generated)*

## 4. Assembly
### 4.1 Attach landing gear and all motor mounts to the main quadcopter frame
*(not yet generated)*

### 4.2 Mount brushless motors to motor mounts and propellers to motors
*(not yet generated)*

### 4.3 Mount ESCs to their respective mounts and secure mounts to motor arms using zip ties
*(not yet generated)*

### 4.4 Mount Flight Controller into its enclosure and attach to frame with standoffs
*(not yet generated)*

### 4.5 Mount DC-DC Boost Converter and RC Receiver onto their mounts and attach to frame
*(not yet generated)*

### 4.6 Insert light sensors into housings and attach housings to the frame
*(not yet generated)*

### 4.7 Mount solar panels onto their mounts and attach mounts to the frame
*(not yet generated)*

### 4.8 Secure LiPo battery into its tray and attach tray to the main frame
*(not yet generated)*
